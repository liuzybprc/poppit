use strict;


	
	my $negative_name="negative.txt";

############
#To construct the prediction model based on the golden standard datasets
##############
	
	my %lr;
	system("perl LR-peptide.pl $negative_name");
	open(IN,"LR-peptide.txt")||die;
	while(<IN>){
		if($_=~/^feature/){
			$_=<IN>;
		}
		chomp $_;
		my @array=split(/\t/,$_);
		if($array[3] eq "0\/0"){
			next;
		}
		elsif($array[3]=~/\/0/){
			$array[3]=100;
		}
		if(!exists $lr{$array[0]}){
			$lr{$array[0]}=$array[3];
		}
		else{
			$lr{$array[0]}=$lr{$array[0]}."\t".$array[3];
		}
	}
	close IN;
	unlink "LR-peptide.txt";
		
	
	
	
	
	
	system("perl LR-der.pl $negative_name");
	open(IN,"LR-der.txt")||die;
	while(<IN>){
		if($_=~/^feature/){
			$_=<IN>;
		}
		chomp $_;
		my @array=split(/\t/,$_);
		if($array[3] eq "0\/0"){
			next;
		}
		elsif($array[3]=~/\/0/){
			$array[3]=100;
		}
		if(!exists $lr{$array[0]}){
			$lr{$array[0]}=$array[3];
		}
		else{
			$lr{$array[0]}=$lr{$array[0]}."\t".$array[3];
		}
	}
	close IN;
	unlink "LR-der.txt";
	
	
	
	
	
	
	
	open(OUT,">model.txt")||die;
	while((my $key, my $value)=each %lr){
		print OUT "$key\t$value\n";
	}
	close OUT;
	#################################################


	########
	
	
	
		my %golden;
		open(IN,"integrated_targets-4-peptide.txt")||die;
		while(<IN>){
			chomp $_;
			$golden{$_}="";
		}
		close IN;
		
		my %g;
		my %test_score;
		my %test_lr;
		open(IN,"input.txt")||die;
		while(<IN>){
			chomp $_;
			if(exists $golden{$_}){
				$g{$_}="";
				next;
			}
			$test_score{$_}=1;
			$test_lr{$_}="";
		}
		close IN;
		
		
		
		
		open(IN,"human_SP_proteins2properties.txt")||die;
		while(<IN>){
			if($_=~/^pro/){
				$_=<IN>;
			}
			chomp $_;
			my @array=split(/\t/,$_);
			if(!exists $test_score{$array[0]}){
				next;
			}
			
		
			if($array[6]==1){
				my $name="signal_mol_2";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			else{
				my $name="signal_mol_1";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			
		
			
			
			if($array[5]==1){
				my $name="transmem_2";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			else{
				my $name="transmem_1";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			
			
			if($array[4]==1){
				my $name="signal_peptide_2";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			else{
				my $name="signal_peptide_1";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			
			
			
		
		}
		close IN;
		
		
		
		
		
		
			
		
	
		
		
		open(IN,"human_SP_proteins2der-peptide.txt")||die;
		while(<IN>){
			if($_=~/^pro/){
				$_=<IN>;
			}
			chomp $_;
			my @array=split(/\t/,$_);
			if(!exists $test_score{$array[0]}){
				next;
			}
		
			if($array[1] eq ""){
				my $name="der_1";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			elsif($array[1]<=20){
				my $name="der_2";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			elsif($array[1]<=30){
				my $name="der_3";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			elsif($array[1]<=100){
				my $name="der_4";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			else{
				my $name="der_5";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
		}
		close IN;
		
		
		open(OUT,">peptide_target_estimation_score.txt")||die;
		print OUT "SP_AC\tcombined_LR\tLR_signal_mol\tLR_transmem\tLR_signal_peptide\tLR_DER\n";
		while((my $key, my $value)=each %g){
			print OUT "$key\tgolden\n";
		}
		while((my $key, my $value)=each %test_score){
			print OUT "$key\t$value\t$test_lr{$key}\n";
		}
		close OUT;

	