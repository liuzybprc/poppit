use strict;

my $negative_name=shift;

my $label=0;
open(IN,"integrated_targets-4-peptide.txt")||die;
open(OUT1,">positive-1.txt")||die;
open(OUT2,">positive-2.txt")||die;
open(OUT3,">positive-3.txt")||die;
open(OUT4,">positive-4.txt")||die;
open(OUT5,">positive-5.txt")||die;
open(OUT6,">positive-6.txt")||die;
open(OUT7,">positive-7.txt")||die;
open(OUT8,">positive-8.txt")||die;
open(OUT9,">positive-9.txt")||die;
open(OUT10,">positive-10.txt")||die;
while(<IN>){
	$label++;
	if($label%10==1){
		print OUT1 $_;
	}
	elsif($label%10==2){
		print OUT2 $_;
	}
	elsif($label%10==3){
		print OUT3 $_;
	}
	elsif($label%10==4){
		print OUT4 $_;
	}
	elsif($label%10==5){
		print OUT5 $_;
	}
	elsif($label%10==6){
		print OUT6 $_;
	}
	elsif($label%10==7){
		print OUT7 $_;
	}
	elsif($label%10==8){
		print OUT8 $_;
	}
	elsif($label%10==9){
		print OUT9 $_;
	}
	elsif($label%10==0){
		print OUT10 $_;
	}
}
close IN;
close OUT1;
close OUT2;
close OUT3;
close OUT4;
close OUT5;
close OUT6;
close OUT7;
close OUT8;
close OUT9;
close OUT10;

		

$label=0;
open(IN,"$negative_name")||die;
open(OUT1,">negative-1.txt")||die;
open(OUT2,">negative-2.txt")||die;
open(OUT3,">negative-3.txt")||die;
open(OUT4,">negative-4.txt")||die;
open(OUT5,">negative-5.txt")||die;
open(OUT6,">negative-6.txt")||die;
open(OUT7,">negative-7.txt")||die;
open(OUT8,">negative-8.txt")||die;
open(OUT9,">negative-9.txt")||die;
open(OUT10,">negative-10.txt")||die;
while(<IN>){
	$label++;
	if($label%10==1){
		print OUT1 $_;
	}
	elsif($label%10==2){
		print OUT2 $_;
	}
	elsif($label%10==3){
		print OUT3 $_;
	}
	elsif($label%10==4){
		print OUT4 $_;
	}
	elsif($label%10==5){
		print OUT5 $_;
	}
	elsif($label%10==6){
		print OUT6 $_;
	}
	elsif($label%10==7){
		print OUT7 $_;
	}
	elsif($label%10==8){
		print OUT8 $_;
	}
	elsif($label%10==9){
		print OUT9 $_;
	}
	elsif($label%10==0){
		print OUT10 $_;
	}
}
close IN;
close OUT1;
close OUT2;
close OUT3;
close OUT4;
close OUT5;
close OUT6;
close OUT7;
close OUT8;
close OUT9;
close OUT10;

		
my $big_n=20196;
my %big_m;
my %hash;
open(IN,"human_SP_proteins2pfam_domain_kind.txt")||die;
while(<IN>){
	chomp $_;
	my @array=split(/\t/,$_);
	if($array[1] eq ""){
		next;
	}
	$hash{$array[0]}=$array[1];
	my @arr=split(/\|/,$array[1]);
	for(my $i=0;$i<@arr;$i++){
		if(!exists $big_m{$arr[$i]}){
			$big_m{$arr[$i]}=1;
		}
		else{
			$big_m{$arr[$i]}++;
		}
	}
}
close IN;



open(OUT,">lr-data-der-$negative_name.txt")||die;
for(my $fold=1;$fold<=10;$fold++){
	
	my $small_n=0;
	my %small_m;
	for(my $count=1;$count<=10;$count++){
		if($count==$fold){
			next;
		}
		open(IN,"positive-$count.txt")||die;
		while(<IN>){
			chomp $_;
			$small_n++;
			if(exists $hash{$_}){
				my @array=split(/\|/,$hash{$_});
				for(my $i=0;$i<@array;$i++){
					if(!exists $small_m{$array[$i]}){
						$small_m{$array[$i]}=1;
					}
					else{
						$small_m{$array[$i]}++;
					}
				}
			}
		}		
		close IN;
	}
		
	
	while((my $key, my $value)=each %small_m){
		if(!exists $big_m{$key}){
			print "abbb\n";
		}
		$small_m{$key}=$value/$small_n/($big_m{$key}/$big_n);
	}
	
	
	
	open(IN,"positive-$fold.txt")||die;
	while(<IN>){
		chomp $_;
		if(!exists $hash{$_}){
			print OUT "$_\t\n";
		}
		else{
			my @array=split(/\|/,$hash{$_});
			my $r="";
			for(my $i=0;$i<@array;$i++){
				if(exists $small_m{$array[$i]}){
					if($r eq ""){
						$r=$small_m{$array[$i]};
					}
					else{
						if($small_m{$array[$i]}>$r){
							$r=$small_m{$array[$i]};
						}
					}
				}
			}
			print OUT "$_\t$r\n";
		}
	}
	close IN;
	
	open(IN,"negative-$fold.txt")||die;
	while(<IN>){
		chomp $_;
		if(!exists $hash{$_}){
			print OUT "$_\t\n";
		}
		else{
			my @array=split(/\|/,$hash{$_});
			my $r="";
			for(my $i=0;$i<@array;$i++){
				if(exists $small_m{$array[$i]}){
					if($r eq ""){
						$r=$small_m{$array[$i]};
					}
					else{
						if($small_m{$array[$i]}>$r){
							$r=$small_m{$array[$i]};
						}
					}
				}
			}
			print OUT "$_\t$r\n";
		}
	}
	close IN;
	
	undef %small_m;
	
	
	
}
close OUT;



for(my $i=1;$i<=10;$i++){
	unlink "positive-$i.txt";
	unlink "negative-$i.txt";
}
			

		




my %t;
my $tt=0;
open(IN,"integrated_targets-4-peptide.txt")||die;
while(<IN>){
	chomp $_;
	$t{$_}="";
	$tt++;
}
close IN;



my %f;
my $ff=0;
open(IN,"$negative_name")||die;
while(<IN>){
	chomp $_;
	$f{$_}="";
	$ff++;
}
close IN;


my %tp;
my %fp;
my %head;
open(IN,"lr-data-der-$negative_name.txt")||die;
while(<IN>){
	chomp $_;
	my @array=split(/\t/,$_);
	

	if($array[1] eq ""){
		my $name="der_1";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	elsif($array[1]<=20){
		my $name="der_2";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	elsif($array[1]<=30){
		my $name="der_3";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	elsif($array[1]<=100){
		my $name="der_4";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	else{
		my $name="der_5";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
}
close IN;
unlink "lr-data-der-$negative_name.txt";



my @order=keys %head;
@order=sort @order;
open(OUT,">LR-der.txt")||die;
print OUT "feature\tTP\tFP\tLR\tTP\+FP\n";
for(my $i=0;$i<@order;$i++){
	
	
	print OUT "$order[$i]\t";
	my $total=0;
	
	my $fenzi=0;
	if(exists $tp{$order[$i]}){
		$fenzi=$tp{$order[$i]}/$tt;
		$total=$total+$tp{$order[$i]};
		print OUT "$tp{$order[$i]}\t";
	}
	else{
		print OUT "0\t";
	}
	
	my $fenmu=0;
	if(exists $fp{$order[$i]}){
		$fenmu=$fp{$order[$i]}/$ff;
		$total=$total+$fp{$order[$i]};
		print OUT "$fp{$order[$i]}\t";
	}
	else{
		print OUT "0\t";
	}
	
	my $lr="";
	if($fenmu!=0){
		$lr=$fenzi/$fenmu;
	}
	else{
		$lr="$fenzi\/0";
	}
	print OUT "$lr\t$total\n";
	
}
close OUT;