use strict;

my $negative_name=shift;

my %t;
my $tt=0;
open(IN,"integrated_targets-4-peptide.txt")||die;
while(<IN>){
	chomp $_;
	$t{$_}="";
	$tt++;
}
close IN;



my %f;
my $ff=0;
open(IN,"$negative_name")||die;
while(<IN>){
	chomp $_;
	$f{$_}="";
	$ff++;
}
close IN;


my %tp;
my %fp;
my %head;

open(IN,"human_SP_proteins2properties.txt")||die;
while(<IN>){
	if($_=~/^pro/){
		$_=<IN>;
	}
	chomp $_;
	my @array=split(/\t/,$_);
	
	
	
	if($array[4]==1){
		my $name="signal_peptide_2";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	else{
		my $name="signal_peptide_1";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	
	
	
	if($array[5]==1){
		my $name="transmem_2";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	else{
		my $name="transmem_1";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	
	
	
	
	
	
	if($array[6]==1){
		my $name="signal_mol_2";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	else{
		my $name="signal_mol_1";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	
	
}
close IN;






my @order=keys %head;
@order=sort @order;
open(OUT,">LR-peptide.txt")||die;
print OUT "feature\tTP\tFP\tLR\tTP\+FP\n";
for(my $i=0;$i<@order;$i++){
	
	
	print OUT "$order[$i]\t";
	my $total=0;
	
	my $fenzi=0;
	if(exists $tp{$order[$i]}){
		$fenzi=$tp{$order[$i]}/$tt;
		$total=$total+$tp{$order[$i]};
		print OUT "$tp{$order[$i]}\t";
	}
	else{
		print OUT "0\t";
	}
	
	my $fenmu=0;
	if(exists $fp{$order[$i]}){
		$fenmu=$fp{$order[$i]}/$ff;
		$total=$total+$fp{$order[$i]};
		print OUT "$fp{$order[$i]}\t";
	}
	else{
		print OUT "0\t";
	}
	
	my $lr="";
	if($fenmu!=0){
		$lr=$fenzi/$fenmu;
	}
	else{
		$lr="$fenzi\/0";
	}
	print OUT "$lr\t$total\n";
	
}
close OUT;
