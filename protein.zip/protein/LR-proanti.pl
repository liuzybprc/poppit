use strict;

my $negative_name=shift;

my %t;
my $tt=0;
open(IN,"integrated_targets-4-proanti.txt")||die;
while(<IN>){
	chomp $_;
	$t{$_}="";
	$tt++;
}
close IN;



my %f;
my $ff=0;
open(IN,"$negative_name")||die;
while(<IN>){
	chomp $_;
	$f{$_}="";
	$ff++;
}
close IN;


my %tp;
my %fp;
my %head;

open(IN,"human_SP_proteins2properties.txt")||die;
while(<IN>){
	if($_=~/^pro/){
		$_=<IN>;
	}
	chomp $_;
	my @array=split(/\t/,$_);
	

	
	#outnet_betweenness
	if($array[1] eq ""){
		my $name="ournet_betweenness_1";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	elsif($array[1]==0){
		my $name="ournet_betweenness_2";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	elsif(($array[1]>0)and($array[1]<0.00001)){
		my $name="ournet_betweenness_3";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif(($array[1]>=0.00001)and($array[1]<0.0001)){
		my $name="ournet_betweenness_4";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif(($array[1]>=0.0001)and($array[1]<0.0005)){
		my $name="ournet_betweenness_5";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif($array[1]>=0.0005){
		my $name="ournet_betweenness_6";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	else{
		print "abbbb6\n";
	}
	
	
	
	
	
	if($array[2] eq ""){
		my $name="path_num_1";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif($array[2]==0){
		my $name="path_num_2";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif($array[2]==1){
		my $name="path_num_3";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif(($array[2]>=2)and($array[2]<5)){
		my $name="path_num_4";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif(($array[2]>=5)and($array[2]<10)){
		my $name="path_num_5";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif($array[2]>=10){
		
		my $name="path_num_6";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	else{
		print "abbbb11\n";
	}
	
	
	
	
	if($array[3] eq ""){
		my $name="tf_indegree_1";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif($array[3]==1){
		my $name="tf_indegree_2";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif(($array[3]>=2)and($array[3]<=3)){
		my $name="tf_indegree_3";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif(($array[3]>=4)and($array[3]<=6)){
		my $name="tf_indegree_4";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif(($array[3]>=7)and($array[3]<=10)){
		my $name="tf_indegree_5";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	elsif($array[3]>=11){
		my $name="tf_indegree_6";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}	
	else{
		print "abbbb12\n";
	}
	
	

	
	if($array[4]==1){
		my $name="signal_peptide_2";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	else{
		my $name="signal_peptide_1";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	
	
	
	if($array[5]==1){
		my $name="transmem_2";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	else{
		my $name="transmem_1";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	
	
	
	
	
	if($array[6]==1){
		my $name="signal_mol_2";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	else{
		my $name="signal_mol_1";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	
	
	if($array[7]==1){
		my $name="tf_2";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	else{
		my $name="tf_1";
		$head{$name}="";
		if(exists $t{$array[0]}){
			if(!exists $tp{$name}){
				$tp{$name}=1;
			}
			else{
				$tp{$name}++;
			}
		}
		elsif(exists $f{$array[0]}){
			if(!exists $fp{$name}){
				$fp{$name}=1;
			}
			else{
				$fp{$name}++;
			}
		}
	}
	
}
close IN;




my @order=keys %head;
@order=sort @order;
open(OUT,">LR-proanti-$negative_name.txt")||die;
print OUT "feature\tTP\tFP\tLR\tTP\+FP\n";
for(my $i=0;$i<@order;$i++){
	
	
	print OUT "$order[$i]\t";
	my $total=0;
	
	my $fenzi=0;
	if(exists $tp{$order[$i]}){
		$fenzi=$tp{$order[$i]}/$tt;
		$total=$total+$tp{$order[$i]};
		print OUT "$tp{$order[$i]}\t";
	}
	else{
		print OUT "0\t";
	}
	
	my $fenmu=0;
	if(exists $fp{$order[$i]}){
		$fenmu=$fp{$order[$i]}/$ff;
		$total=$total+$fp{$order[$i]};
		print OUT "$fp{$order[$i]}\t";
	}
	else{
		print OUT "0\t";
	}
	
	my $lr="";
	if($fenmu!=0){
		$lr=$fenzi/$fenmu;
	}
	else{
		$lr="$fenzi\/0";
	}
	print OUT "$lr\t$total\n";
	
}
close OUT;
