use strict;
use Statistics::R;




	
	my $negative_name="negative.txt";
	
######################
#To construct the prediction model based on the golden standard datasets
######################
	my %lr;
	system("perl LR-proanti.pl $negative_name");
	open(IN,"LR-proanti-$negative_name.txt")||die;
	while(<IN>){
		if($_=~/^feature/){
			$_=<IN>;
		}
		chomp $_;
		my @array=split(/\t/,$_);
		if($array[3] eq "0\/0"){
			next;
		}
		elsif($array[3]=~/\/0/){
			$array[3]=100;
		}
		$lr{$array[0]}=$array[3];

	}
	close IN;
	unlink "LR-proanti-$negative_name.txt";
		
	
	system("perl LR-der.pl $negative_name");
	open(IN,"LR-der-$negative_name.txt")||die;
	while(<IN>){
		if($_=~/^feature/){
			$_=<IN>;
		}
		chomp $_;
		my @array=split(/\t/,$_);
		if($array[3] eq "0\/0"){
			next;
		}
		elsif($array[3]=~/\/0/){
			$array[3]=100;
		}
		$lr{$array[0]}=$array[3];
	}
	close IN;
	unlink "LR-der-$negative_name.txt";
	unlink "lr-data-der-$negative_name.txt";
	
	
	#output parameters of the prediction model
	open(OUT,">model.txt")||die;
	while((my $key, my $value)=each %lr){
		print OUT "$key\t$value\n";
	}
	close OUT;
	
	


#############
#To predict
#############
		


		my %golden;
		open(IN,"integrated_targets-4-proanti.txt")||die;
		while(<IN>){
			chomp $_;
			$golden{$_}="";
		}
		close IN;
		
		my %g;
		my %test_score;
		my %test_lr;
		open(IN,"input.txt")||die;
		while(<IN>){
			chomp $_;
			if(exists $golden{$_}){
				$g{$_}="";
				next;
			}
			$test_score{$_}=1;
			$test_lr{$_}="";
		}
		close IN;

			
		
		open(IN,"human_SP_proteins2properties.txt")||die;
		while(<IN>){
			if($_=~/^pro/){
				$_=<IN>;
			}
			chomp $_;
			my @array=split(/\t/,$_);
			if(!exists $test_score{$array[0]}){
				next;
			}
			
			
			
			
			if($array[3] eq ""){
				my $name="tf_indegree_1";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif($array[3]==1){
				my $name="tf_indegree_2";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif(($array[3]>=2)and($array[3]<=3)){
				my $name="tf_indegree_3";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif(($array[3]>=4)and($array[3]<=6)){
				my $name="tf_indegree_4";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif(($array[3]>=7)and($array[3]<=10)){
				my $name="tf_indegree_5";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif($array[3]>=11){
				my $name="tf_indegree_6";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			else{
				print "abbbb12\n";
			}
			
			
			#outnet_betweenness
			if($array[1] eq ""){
				my $name="ournet_betweenness_1";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			elsif($array[1]==0){
				my $name="ournet_betweenness_2";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			elsif(($array[1]>0)and($array[1]<0.00001)){
				my $name="ournet_betweenness_3";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif(($array[1]>=0.00001)and($array[1]<0.0001)){
				my $name="ournet_betweenness_4";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif(($array[1]>=0.0001)and($array[1]<0.0005)){
				my $name="ournet_betweenness_5";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif($array[1]>=0.0005){
				my $name="ournet_betweenness_6";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			else{
				print "abbbb6\n";
			}
			
			
			
			if($array[2] eq ""){
				my $name="path_num_1";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif($array[2]==0){
				my $name="path_num_2";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif($array[2]==1){
				my $name="path_num_3";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif(($array[2]>=2)and($array[2]<5)){
				my $name="path_num_4";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif(($array[2]>=5)and($array[2]<10)){
				my $name="path_num_5";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			elsif($array[2]>=10){
				
				my $name="path_num_6";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}	
			else{
				print "abbbb11\n";
			}
			
			
			if($array[4]==1){
				my $name="signal_peptide_2";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			else{
				my $name="signal_peptide_1";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			
			
			
			if($array[6]==1){
				my $name="signal_mol_2";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			else{
				my $name="signal_mol_1";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			
				
			
			if($array[7]==1){
				my $name="tf_2";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			else{
				my $name="tf_1";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			
			
			
			if($array[5]==1){
				my $name="transmem_2";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			else{
				my $name="transmem_1";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
		
		}
		close IN;
		
		
		open(IN,"human_SP_proteins2der-proanti.txt")||die;
		while(<IN>){
			if($_=~/^pro/){
				$_=<IN>;
			}
			chomp $_;
			my @array=split(/\t/,$_);
			if(!exists $test_score{$array[0]}){
				next;
			}
			
			if($array[1] eq ""){
				my $name="der_1";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			elsif($array[1]<=10){
				my $name="der_2";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			elsif($array[1]<=20){
				my $name="der_3";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			elsif($array[1]<=50){
				my $name="der_4";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
			else{
				my $name="der_5";
				if(exists $lr{$name}){
					$test_score{$array[0]}=$test_score{$array[0]}*$lr{$name};
					$test_lr{$array[0]}=$test_lr{$array[0]}."\t".$lr{$name};
				}
				else{
					print "$array[0]\n";
				}
			}
		}
		close IN;
		
		
		open(OUT,">protein_target_estimation_score.txt")||die;
		print OUT "SP_AC\tcombined_LR\tLR_tf_indegree\tLR_betweenness_ppi\tLR_path_num\tLR_signal_peptide\tLR_signal_mol\tLR_tf\tLR_transmem\tLR_DER\n";
		while((my $key,my $value)=each %g){
			print OUT "$key\tgolden\n";
		}
			
		while((my $key, my $value)=each %test_score){
			print OUT "$key\t$value\t$test_lr{$key}\n";
		}
		close OUT;
		
		
		


	
			
		
